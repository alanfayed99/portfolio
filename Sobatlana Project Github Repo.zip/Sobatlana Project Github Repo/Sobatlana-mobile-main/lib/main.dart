import 'package:flutter/material.dart';
import 'package:sobatlana/app/app.dart';

void main() {
  runApp(MyApp());
}
