import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';

import '../../resources/assets_manager.dart';
import '../../resources/color_manager.dart';
import '../../resources/routes_manager.dart';
import '../../resources/strings_manager.dart';
import '../../resources/values_manager.dart';

class SetUpProfile extends StatefulWidget {
  SetUpProfile({Key? key}) : super(key: key);

  @override
  State<SetUpProfile> createState() => _SetUpProfileState();
}

class _SetUpProfileState extends State<SetUpProfile> {
  final _formKey = GlobalKey<FormState>();

  final _displayNameValidator = MultiValidator([
    RequiredValidator(errorText: 'Display Name is required'),
  ]);

  final TextEditingController? _displayNameController = TextEditingController();
  final TextEditingController? _bioController = TextEditingController();

  String _chosenValue = "Android";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height),
            Positioned(
              top: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.7,
                color: ColorManager.primary,
                child: Stack(
                  children: [
                    const Align(
                      alignment: Alignment.topRight,
                      child: Image(
                        image: AssetImage(ImageAssets.logoPutih),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 30),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.1,
                          ),
                          Text(
                            AppStrings.configureProfile,
                            style: Theme.of(context).textTheme.headline2,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).size.height * 0.22,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Card(
                  margin: EdgeInsets.zero,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25.0),
                          topRight: Radius.circular(25.0))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 30),
                    child: Column(
                      children: [
                        Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              CircleAvatar(
                                backgroundImage:
                                    AssetImage(ImageAssets.splashLogo),
                                radius: 70,
                              ),
                              const SizedBox(height: AppSize.s12),
                              Text(
                                "Add your profile photo",
                                style: Theme.of(context)
                                    .textTheme
                                    .subtitle1
                                    ?.copyWith(color: Colors.black),
                              ),
                              const SizedBox(height: AppSize.s20),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Email",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      controller: _displayNameController,
                                      validator: _displayNameValidator,
                                      decoration: InputDecoration(
                                        labelText: 'Display Name',
                                        labelStyle: Theme.of(context)
                                            .textTheme
                                            .bodyText2
                                            ?.copyWith(color: Colors.black),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppSize.s12),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Gender",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s20),
                              Container(
                                padding: const EdgeInsets.all(0.0),
                                child: DropdownButton<String>(
                                  value: _chosenValue,
                                  //elevation: 5,
                                  style: TextStyle(color: Colors.black),

                                  items: <String>[
                                    'Android',
                                    'IOS',
                                    'Flutter',
                                    'Node',
                                    'Java',
                                    'Python',
                                    'PHP',
                                  ].map<DropdownMenuItem<String>>(
                                      (String value) {
                                    return DropdownMenuItem<String>(
                                      value: value,
                                      child: Text(value),
                                    );
                                  }).toList(),
                                  hint: Text(
                                    "Please choose a langauage",
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontSize: 16,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  onChanged: (value) {
                                    setState(() {
                                      _chosenValue = value!;
                                    });
                                  },
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Bio",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      controller: _bioController,
                                      decoration: InputDecoration(
                                        labelText: 'Bio',
                                        labelStyle: Theme.of(context)
                                            .textTheme
                                            .bodyText2
                                            ?.copyWith(color: Colors.black),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: AppSize.s40),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: SizedBox(
                            width: 140,
                            child: ElevatedButton(
                              child: const Text(AppStrings.saveAndCont),
                              onPressed: () {
                                Navigator.pushReplacementNamed(
                                    context, Routes.welcomeRoute);
                              },
                              style: ElevatedButton.styleFrom(
                                  primary: ColorManager.primary,
                                  onPrimary: Colors.white,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0),
                                  ),
                                  padding: const EdgeInsets.all(15)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
