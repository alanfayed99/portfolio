import 'package:flutter/material.dart';

import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:form_field_validator/form_field_validator.dart';

import '../../resources/assets_manager.dart';
import '../../resources/color_manager.dart';
import '../../resources/routes_manager.dart';
import '../../resources/strings_manager.dart';
import '../../resources/values_manager.dart';

class SetUpAccount extends StatefulWidget {
  SetUpAccount({Key? key}) : super(key: key);

  @override
  State<SetUpAccount> createState() => _SetUpAccountState();
}

class _SetUpAccountState extends State<SetUpAccount> {
  final _formKey = GlobalKey<FormState>();
  final _emailValidator = MultiValidator([
    RequiredValidator(errorText: 'Email is required'),
    EmailValidator(errorText: 'Enter a valid email')
  ]);
  final _passwordValidator = MultiValidator([
    RequiredValidator(errorText: 'Password is required'),
    MinLengthValidator(8, errorText: 'Password must be at least 8 digits long'),
    PatternValidator(r'(?=.*?[#?!@$%^&*-])',
        errorText: 'Passwords must have at least one special character')
  ]);
  final TextEditingController? _emailController = TextEditingController();
  final TextEditingController? _usernameController = TextEditingController();
  final TextEditingController? _confirmPasswordController =
      TextEditingController();
  final TextEditingController? _passwordController = TextEditingController();

  bool _isLoginError = false;

  bool _isObscure = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height),
            Positioned(
              top: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.7,
                color: ColorManager.primary,
                child: Stack(
                  children: [
                    const Align(
                      alignment: Alignment.topRight,
                      child: Image(
                        image: AssetImage(ImageAssets.logoPutih),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 30),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.1,
                          ),
                          Text(
                            AppStrings.setUpAcc,
                            style: Theme.of(context).textTheme.headline2,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).size.height * 0.22,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Card(
                  margin: EdgeInsets.zero,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(25.0),
                      topRight: Radius.circular(25.0),
                    ),
                  ),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30, vertical: 30),
                    child: Column(
                      children: [
                        Text(
                          AppStrings.setUpAccDesc,
                          textAlign: TextAlign.center,
                          style:
                              Theme.of(context).textTheme.subtitle1?.copyWith(
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                        ),
                        const SizedBox(height: AppSize.s28),
                        Form(
                          key: _formKey,
                          child: Column(
                            children: [
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Email",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      controller: _emailController,
                                      validator: _emailValidator,
                                      decoration: InputDecoration(
                                        labelText: 'Your Email',
                                        labelStyle: Theme.of(context)
                                            .textTheme
                                            .bodyText2
                                            ?.copyWith(color: Colors.black),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppSize.s20),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Username",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      controller: _usernameController,
                                      decoration: InputDecoration(
                                        labelText: 'Your Username',
                                        labelStyle: Theme.of(context)
                                            .textTheme
                                            .bodyText2
                                            ?.copyWith(color: Colors.black),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(height: AppSize.s20),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Password",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      controller: _passwordController,
                                      validator: _passwordValidator,
                                      obscureText: _isObscure,
                                      enableSuggestions: false,
                                      autocorrect: false,
                                      decoration: InputDecoration(
                                        labelText: 'Your Password',
                                        labelStyle: Theme.of(context)
                                            .textTheme
                                            .bodyText2
                                            ?.copyWith(color: Colors.black),
                                        suffixIcon: IconButton(
                                          icon: Icon(_isObscure
                                              ? Icons.visibility
                                              : Icons.visibility_off),
                                          onPressed: () {
                                            setState(
                                              () {
                                                _isObscure = !_isObscure;
                                              },
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  height: 10),
                              Visibility(
                                visible: _isLoginError,
                                child: Column(
                                  children: [
                                    const Text(
                                      'Email or password is incorrect',
                                      style: TextStyle(color: Colors.red),
                                    ),
                                    SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        height: 5)
                                  ],
                                ),
                              ),
                              const SizedBox(height: AppSize.s20),
                              Align(
                                alignment: Alignment.topLeft,
                                child: Text(
                                  "Confirm password",
                                  style: Theme.of(context)
                                      .textTheme
                                      .subtitle1
                                      ?.copyWith(color: Colors.black),
                                ),
                              ),
                              const SizedBox(height: AppSize.s12),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: TextFormField(
                                      controller: _confirmPasswordController,
                                      validator: _passwordValidator,
                                      obscureText: _isObscure,
                                      enableSuggestions: false,
                                      autocorrect: false,
                                      decoration: InputDecoration(
                                        labelText: 'Your Password',
                                        labelStyle: Theme.of(context)
                                            .textTheme
                                            .bodyText2
                                            ?.copyWith(color: Colors.black),
                                        suffixIcon: IconButton(
                                          icon: Icon(_isObscure
                                              ? Icons.visibility
                                              : Icons.visibility_off),
                                          onPressed: () {
                                            setState(
                                              () {
                                                _isObscure = !_isObscure;
                                              },
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(
                                  width: MediaQuery.of(context).size.width,
                                  height: 10),
                              Visibility(
                                visible: _isLoginError,
                                child: Column(
                                  children: [
                                    const Text(
                                      'Email or password is incorrect',
                                      style: TextStyle(color: Colors.red),
                                    ),
                                    SizedBox(
                                        width:
                                            MediaQuery.of(context).size.width,
                                        height: 5)
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: AppSize.s40),
                        Row(
                          children: [
                            TextButton(
                                onPressed: () {},
                                child: Text("Have an account already?")),
                            Expanded(
                              child: ElevatedButton(
                                child: const Text(AppStrings.saveAndCont),
                                onPressed: () {
                                  Navigator.pushReplacementNamed(
                                      context, Routes.setUpProfileRoute);
                                },
                                style: ElevatedButton.styleFrom(
                                    primary: ColorManager.primary,
                                    onPrimary: Colors.white,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5.0),
                                    ),
                                    padding: const EdgeInsets.all(15)),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
