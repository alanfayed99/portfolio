import 'package:flutter/material.dart';

class InterestCard extends StatefulWidget {
  InterestCard({Key? key}) : super(key: key);

  @override
  State<InterestCard> createState() => _InterestCardState();
}

class _InterestCardState extends State<InterestCard> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
