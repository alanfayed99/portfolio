import 'package:flutter/material.dart';

import '../../resources/assets_manager.dart';
import '../../resources/color_manager.dart';
import '../../resources/routes_manager.dart';
import '../../resources/strings_manager.dart';
import '../../resources/values_manager.dart';

class ShowRecommendation extends StatefulWidget {
  ShowRecommendation({Key? key}) : super(key: key);

  @override
  State<ShowRecommendation> createState() => _ShowRecommendationState();
}

class _ShowRecommendationState extends State<ShowRecommendation> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height),
            Positioned(
              top: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.7,
                color: ColorManager.primary,
                child: Stack(
                  children: [
                    const Align(
                      alignment: Alignment.topRight,
                      child: Image(
                        image: AssetImage(ImageAssets.logoPutih),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 30),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.1,
                          ),
                          Text(
                            AppStrings.welcomeShort,
                            style: Theme.of(context).textTheme.headline2,
                          ),
                          const SizedBox(height: AppSize.s12),
                          Text(
                            AppStrings.pickInterest,
                            style: Theme.of(context)
                                .textTheme
                                .subtitle2
                                ?.copyWith(fontWeight: FontWeight.normal),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).size.height * 0.27,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                child: Card(
                  margin: EdgeInsets.zero,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25.0),
                          topRight: Radius.circular(25.0))),
                  child: Container(
                    child: SingleChildScrollView(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 30),
                        child: Column(
                          children: [
                            GridView.builder(
                              shrinkWrap: true,
                              itemCount: options.length,
                              itemBuilder: (BuildContext context, int index) =>
                                  GridOptions(layout: options[index]),
                              gridDelegate:
                                  const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                mainAxisSpacing: 5.0,
                                crossAxisSpacing: 5.0,
                              ),
                            ),
                            const SizedBox(height: AppSize.s40),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: SizedBox(
                                width: 140,
                                child: ElevatedButton(
                                  child: const Text(AppStrings.cont),
                                  onPressed: () {
                                    Navigator.pushReplacementNamed(
                                        context, Routes.welcomeRoute);
                                  },
                                  style: ElevatedButton.styleFrom(
                                      primary: ColorManager.primary,
                                      onPrimary: Colors.white,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(5.0),
                                      ),
                                      padding: const EdgeInsets.all(15)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class GridLayout {
  final String title;
  final String image;

  GridLayout({required this.title, required this.image});
}

List<GridLayout> options = [
  GridLayout(
      title: 'Home',
      image:
          "https://images.unsplash.com/photo-1523580846011-d3a5bc25702b?ixid=MXwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHw%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80"),
  GridLayout(
      title: 'Home',
      image: "https://www.pexels.com/photo/infinity-pool-near-beach-3155666/"),
  GridLayout(
      title: 'Home',
      image: "https://www.pexels.com/photo/infinity-pool-near-beach-3155666/"),
  GridLayout(
      title: 'Home',
      image: "https://www.pexels.com/photo/infinity-pool-near-beach-3155666/"),
  GridLayout(
      title: 'Home',
      image: "https://www.pexels.com/photo/infinity-pool-near-beach-3155666/"),
  GridLayout(
      title: 'Email',
      image:
          "https://external-content.duckduckgo.com/iu/?u=http%3A%2F%2Fmedia.cntraveler.com%2Fphotos%2F56eadd8d37ada0e3667b28f5%2Fmaster%2Fpass%2FGettyImages-527961055.jpg&f=1&nofb=1"),
];

class GridOptions extends StatelessWidget {
  final GridLayout layout;
  // ignore: use_key_in_widget_constructors
  const GridOptions({required this.layout});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Center(
        child: Stack(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(6.0),
              // child: CachedNetworkImage(
              //   width: MediaQuery.of(context).size.width * 0.35,
              //   height: MediaQuery.of(context).size.height * 0.06,
              //   fit: BoxFit.cover,
              //   imageUrl: layout.image,
              // ),
              child: Image(
                width: MediaQuery.of(context).size.width * 0.4,
                height: MediaQuery.of(context).size.height * 0.4,
                fit: BoxFit.cover,
                image: const AssetImage(ImageAssets.exImg),
              ),
            ),
            Container(
              alignment: Alignment.center,
              height: MediaQuery.of(context).size.height * 0.2,
              width: MediaQuery.of(context).size.width * 0.4,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15.0),
                color: Colors.black26,
              ),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Text(
                    layout.title,
                    style: Theme.of(context)
                        .textTheme
                        .subtitle2
                        ?.copyWith(fontWeight: FontWeight.normal),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
