import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:sobatlana/presentation/onboarding/onboarding_view_model.dart';

import '../../domain/models.dart';
import '../../resources/assets_manager.dart';
import '../../resources/color_manager.dart';
import '../../resources/font_manager.dart';
import '../../resources/routes_manager.dart';
import '../../resources/strings_manager.dart';
import '../../resources/values_manager.dart';

class OnboardingView extends StatefulWidget {
  const OnboardingView({Key? key}) : super(key: key);

  @override
  _OnboardingViewState createState() => _OnboardingViewState();
}

class _OnboardingViewState extends State<OnboardingView> {
  final PageController _pageController = PageController(initialPage: 0);
  final OnboardingViewModel _onboardingViewModel = OnboardingViewModel();

  _bind() {
    _onboardingViewModel.start();
  }

  @override
  void initState() {
    _bind();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double h = MediaQuery.of(context).size.height;
    double w = MediaQuery.of(context).size.width;

    return StreamBuilder<SliderViewObject>(
      stream: _onboardingViewModel.outputSliderViewObject,
      builder: (context, snapshot) {
        return _getContentWidget(snapshot.data, h, w);
      },
    );
  }

  Widget _getContentWidget(
      SliderViewObject? sliderViewObject, double he, double wi) {
    if (sliderViewObject == null) {
      return Container();
    } else {
      return Scaffold(
        backgroundColor: ColorManager.primary,
        body: SafeArea(
          child: PageView.builder(
              controller: _pageController,
              itemCount: sliderViewObject.numOfSliders,
              onPageChanged: (index) {
                _onboardingViewModel.onPageChanged(index);
              },
              itemBuilder: (context, index) {
                //return onboarding page
                return OnboardingPage(sliderViewObject.sliderObject);
              }),
        ),
        bottomSheet: Container(
          color: ColorManager.primary,
          height: he * 0.2,
          width: wi,
          child: sliderViewObject.currentIndex == 2
              ? Column(
                  children: [
                    const SizedBox(height: AppSize.s20),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 30),
                      child: Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              child: const Text(
                                AppStrings.signUp,
                                style: TextStyle(
                                    fontWeight: FontWeightManager.bold),
                              ),
                              onPressed: () {
                                Navigator.pushReplacementNamed(
                                    context, Routes.registerRoute);
                              },
                              style: ElevatedButton.styleFrom(
                                primary: ColorManager.white,
                                onPrimary: Colors.black,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5.0),
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(width: AppSize.s20),
                          Expanded(
                            child: ElevatedButton(
                              child: const Text(AppStrings.signIn),
                              onPressed: () {
                                Navigator.pushReplacementNamed(
                                    context, Routes.loginRoute);
                              },
                              style: ElevatedButton.styleFrom(
                                primary: ColorManager.orange,
                                onPrimary: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(5.0),
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                )
              : Column(
                  children: [
                    Container(
                      margin: const EdgeInsets.all(20),
                      child: ElevatedButton(
                        onPressed: () {
                          _pageController.animateToPage(
                              _onboardingViewModel.goNext(),
                              duration: const Duration(
                                  milliseconds: DurationConstant.d300),
                              curve: Curves.bounceInOut);
                        },
                        child: const FaIcon(FontAwesomeIcons.arrowRight),
                        style: ElevatedButton.styleFrom(
                          primary: ColorManager.white,
                          onPrimary: Colors.black,
                          shape: const CircleBorder(),
                          padding: const EdgeInsets.all(15),
                        ),
                      ),
                    ),
                    const SizedBox(height: AppSize.s20),
                  ],
                ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _onboardingViewModel.dispose();
    super.dispose();
  }
}

class OnboardingPage extends StatelessWidget {
  final SliderObject _sliderObject;

  const OnboardingPage(this._sliderObject, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const SizedBox(height: AppSize.s40),
        const Image(image: AssetImage(ImageAssets.logoKanan)),
        const SizedBox(height: AppSize.s60),
        Center(
          child: Padding(
            padding: const EdgeInsets.all(AppMargin.m20),
            child: Column(
              children: [
                Image(
                  image: AssetImage(_sliderObject.image),
                  width: MediaQuery.of(context).size.width * 0.7,
                  height: MediaQuery.of(context).size.height * 0.3,
                ),
                const SizedBox(height: AppSize.s40),
                Text(
                  _sliderObject.title,
                  style: Theme.of(context).textTheme.headline2,
                ),
                const SizedBox(height: AppSize.s20),
                Text(
                  _sliderObject.subtitle,
                  textAlign: TextAlign.center,
                  style: Theme.of(context).textTheme.subtitle2,
                ),
                const SizedBox(height: AppSize.s50),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
