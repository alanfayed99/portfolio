import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:form_field_validator/form_field_validator.dart';

import '../../resources/assets_manager.dart';
import '../../resources/color_manager.dart';
import '../../resources/routes_manager.dart';
import '../../resources/strings_manager.dart';
import '../../resources/values_manager.dart';

class RegisterView extends StatefulWidget {
  const RegisterView({Key? key}) : super(key: key);

  @override
  _RegisterViewState createState() => _RegisterViewState();
}

class _RegisterViewState extends State<RegisterView> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SingleChildScrollView(
        child: Stack(
          children: [
            SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height),
            Positioned(
              top: 0,
              child: Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.7,
                color: ColorManager.primary,
                child: Stack(
                  children: [
                    const Align(
                      alignment: Alignment.topRight,
                      child: Image(
                        image: AssetImage(ImageAssets.logoPutih),
                      ),
                    ),
                    Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Image(
                              image: AssetImage(ImageAssets.splashLogo)),
                          SizedBox(
                              height:
                                  MediaQuery.of(context).size.height * 0.25),
                          Text(
                            AppStrings.signUp,
                            style: Theme.of(context).textTheme.headline2,
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
            Positioned(
              top: MediaQuery.of(context).size.height * 0.6,
              child: SizedBox(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height * 0.4,
                child: Card(
                  margin: EdgeInsets.zero,
                  elevation: 0,
                  shape: const RoundedRectangleBorder(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(25.0),
                          topRight: Radius.circular(25.0))),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 40, vertical: 30),
                    child: Column(
                      children: [
                        const SizedBox(height: AppSize.s40),
                        Text(
                          AppStrings.signUpDesc,
                          textAlign: TextAlign.center,
                          style:
                              Theme.of(context).textTheme.subtitle1?.copyWith(
                                    color: Colors.black,
                                    fontWeight: FontWeight.normal,
                                  ),
                        ),
                        const SizedBox(height: AppSize.s40),
                        Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                icon: const FaIcon(FontAwesomeIcons.google),
                                label: const Text(AppStrings.google),
                                onPressed: () {
                                  Navigator.pushReplacementNamed(
                                      context, Routes.setUpAccRoute);
                                },
                                style: ElevatedButton.styleFrom(
                                  primary: ColorManager.white,
                                  onPrimary: Colors.black,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0),
                                  ),
                                  padding: const EdgeInsets.all(8),
                                ),
                              ),
                            ),
                            const SizedBox(width: AppSize.s20),
                            Expanded(
                              child: ElevatedButton.icon(
                                icon: const FaIcon(FontAwesomeIcons.apple),
                                label: const Text(AppStrings.apple),
                                onPressed: () {
                                  Navigator.pushReplacementNamed(
                                      context, Routes.setUpAccRoute);
                                },
                                style: ElevatedButton.styleFrom(
                                  primary: ColorManager.white,
                                  onPrimary: Colors.black,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(5.0),
                                  ),
                                  padding: const EdgeInsets.all(8),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSize.s20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Text(AppStrings.haveAcc),
                            TextButton(
                              child: Text(
                                'Sign in',
                                style: TextStyle(color: ColorManager.primary),
                              ),
                              onPressed: () {
                                Navigator.pop(context);
                              },
                            )
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
