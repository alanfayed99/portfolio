class SliderObject {
  String title;
  String subtitle;
  String image;

  SliderObject(this.title, this.subtitle, this.image);
}

class Interest {
  String image;
  String desc;

  Interest(this.image, this.desc);
}

class User {
  String userId;
  String email;
  String username;
  String password;
  String image;
  String displayName;
  String bio;

  User(this.userId, this.email, this.username, this.password, this.image,
      this.displayName, this.bio);
}
