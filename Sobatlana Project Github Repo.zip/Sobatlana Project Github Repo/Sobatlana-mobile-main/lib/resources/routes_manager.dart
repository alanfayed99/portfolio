import 'package:flutter/material.dart';
import 'package:sobatlana/presentation/forgot_password/forgot_password.dart';
import 'package:sobatlana/presentation/login/login.dart';
import 'package:sobatlana/presentation/main/main_view.dart';
import 'package:sobatlana/presentation/onboarding/onboarding.dart';
import 'package:sobatlana/presentation/register/register.dart';
import 'package:sobatlana/presentation/set_up_acc/set_up_account.dart';
import 'package:sobatlana/presentation/set_up_interest/set_up_interest.dart';
import 'package:sobatlana/presentation/set_up_profile/set_up_profile.dart';
import 'package:sobatlana/presentation/splash/splash.dart';
import 'package:sobatlana/presentation/welcome/welcome.dart';
import 'package:sobatlana/resources/strings_manager.dart';

import '../presentation/show_recommendation/show_recommendation.dart';

class Routes {
  static const String splashRoute = "/";
  static const String onBoardingRoute = "/onBoarding";
  static const String loginRoute = "/login";
  static const String registerRoute = "/register";
  static const String forgotPasswordRoute = "/forgotPassword";
  static const String mainRoute = "/main";
  static const String welcomeRoute = "/welcome";
  static const String setUpAccRoute = "/setUpAcc";
  static const String setUpProfileRoute = "/setUpProfile";
  static const String setUpInterestRoute = "/setUpInterest";
  static const String showRecommendationRoute = "/showRecommendation";
}

class RouteGenerator {
  static Route<dynamic> getRoute(RouteSettings routeSettings) {
    switch (routeSettings.name) {
      case Routes.splashRoute:
        return MaterialPageRoute(builder: (_) => const SplashView());
      case Routes.loginRoute:
        return MaterialPageRoute(builder: (_) => const LoginView());
      case Routes.onBoardingRoute:
        return MaterialPageRoute(builder: (_) => const OnboardingView());
      case Routes.registerRoute:
        return MaterialPageRoute(builder: (_) => const RegisterView());
      case Routes.forgotPasswordRoute:
        return MaterialPageRoute(builder: (_) => const ForgotPasswordView());
      case Routes.mainRoute:
        return MaterialPageRoute(builder: (_) => const MainView());
      case Routes.welcomeRoute:
        return MaterialPageRoute(builder: (_) => Welcome());
      case Routes.setUpAccRoute:
        return MaterialPageRoute(builder: (_) => SetUpAccount());
      case Routes.setUpProfileRoute:
        return MaterialPageRoute(builder: (_) => SetUpProfile());
      case Routes.setUpInterestRoute:
        return MaterialPageRoute(builder: (_) => SetUpInterest());
      case Routes.showRecommendationRoute:
        return MaterialPageRoute(builder: (_) => ShowRecommendation());
      default:
        return unDefinedRoute();
    }
  }

  static Route<dynamic> unDefinedRoute() {
    return MaterialPageRoute(
      builder: (_) => Scaffold(
        appBar: AppBar(
          title: const Text(AppStrings.noRouteFound),
        ),
        body: const Center(
          child: Text(AppStrings.noRouteFound),
        ),
      ),
    );
  }
}
