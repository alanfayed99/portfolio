class AppStrings {
  static const String noRouteFound = "No Route Found";

  static const String onboardingTitle1 = "DISCOVER";
  static const String onboardingTitle2 = "INTERACT";
  static const String onboardingTitle3 = "EXPLORE";

  static const String onboardingSubtitle1 =
      "Find contents that matches what you want to see";
  static const String onboardingSubtitle2 =
      "Add new friends from all over the world and start interacting with them";
  static const String onboardingSubtitle3 =
      "Meet new friends who have the same interests from the virtual world";

  static const String signUp = "Sign up";
  static const String signUpDesc =
      "Create a new account easily using Google or Apple";
  static const String signIn = "Sign in";
  static const String next = "Next";
  static const String welcome = "Welcome to Sobatlana";
  static const String welcomeShort = "Welcome";
  static const String pickInterest =
      "Choose one or more of interests below to help us provide you with related contents.";
  static const String saveAndCont = "Save & Continue";
  static const String cont = "Continue";

  static const String google = "Google";
  static const String apple = "Apple";
  static const String haveAcc = "Already have an account?";
  static const String setUpAcc = "Set Up Account";
  static const String configureProfile = "Configure Profile";
  static const String setUpAccDesc =
      "Set your username and password in case you want to save it for future use. Email cannot be changed.";
}
