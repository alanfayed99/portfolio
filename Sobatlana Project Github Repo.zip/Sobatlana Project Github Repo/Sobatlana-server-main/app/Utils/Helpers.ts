import _ from 'lodash'

export default class Helpers {
  /**
   * Compute asset url with specific column
   *
   * @param models
   * @param columns
   * @param param2
   * @returns Promise<any>
   */
  public static async preComputeAsset(
    models: any | any[],
    columns: string[],
    { isPrivate }: { isPrivate?: boolean } = { isPrivate: false }
  ) {
    if (Array.isArray(models)) {
      return Promise.all(models.map((model) => this.preComputeAsset(model, columns, { isPrivate })))
    }

    const serializedModel = models.toJSON()
    columns = columns.filter((column) => !!models[column])
    const computedUrl = await Promise.all(
      columns.map((column) => _.get(models, column)[isPrivate ? 'getSignedUrl' : 'getUrl']())
    )
    columns.forEach((column, i) => {
      _.get(serializedModel, column).url = computedUrl[i]
    })

    return serializedModel
  }

  public static simplifyPagination(modelMeta, data) {
    return {
      meta: {
        ...modelMeta,
        first_page_url: undefined,
        last_page_url: undefined,
        next_page_url: undefined,
        previous_page_url: undefined,
      },
      data,
    }
  }
}
