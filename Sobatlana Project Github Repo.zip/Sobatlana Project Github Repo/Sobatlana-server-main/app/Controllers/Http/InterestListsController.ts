import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import InterestList from 'App/Models/InterestList'
import { schema } from '@ioc:Adonis/Core/Validator'

export default class InterestListsController {
  private validationSchema = schema.create({
    name: schema.string(),
    thumbnail: schema.string(),
  })

  public async index({ response }: HttpContextContract) {
    const data = await InterestList.query()

    return response.json({
      status: 'success',
      data,
    })
  }

  public async store({ request, response }: HttpContextContract) {
    const payload = await request.validate({ schema: this.validationSchema })
    const data = await InterestList.create(payload)

    return response.created({
      status: 'success',
      data,
    })
  }
}
