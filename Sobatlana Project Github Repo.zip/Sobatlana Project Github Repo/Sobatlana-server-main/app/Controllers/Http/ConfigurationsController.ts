import { schema } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import ConfigurationService from 'App/Services/ConfigurationService'

export default class ConfigurationsController {
  private configurationService = new ConfigurationService()

  public async getNotifConfig({ response }: HttpContextContract) {
    const config = await this.configurationService.getNotificationConfig()

    return response.json({
      status: 'success',
      data: config,
    })
  }

  public async getPrivacyConfig({ response }: HttpContextContract) {
    const config = await this.configurationService.getPrivacyConfig()

    return response.json({
      status: 'success',
      data: config,
    })
  }

  public async getSecurityConfig({ response }: HttpContextContract) {
    const config = await this.configurationService.getSecurityConfig()

    return response.json({
      status: 'success',
      data: config,
    })
  }

  public async updateNotifConfig({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        message: schema.object.optional().members({
          new_message: schema.boolean(),
          message_request: schema.boolean(),
        }),
        interaction: schema.object.optional().members({
          post_liked: schema.boolean(),
          new_comment: schema.boolean(),
          comment_liked: schema.boolean(),
          name_mentioned: schema.boolean(),
          account_tagged: schema.boolean(),
        }),
        people: schema.object.optional().members({
          new_follower: schema.boolean(),
          recommendation: schema.boolean(),
          follow_request: schema.boolean(),
        }),
        security: schema.object.optional().members({
          password_changed: schema.boolean(),
          new_login: schema.boolean(),
        }),
      }),
    })

    const config = await this.configurationService.updateNotificationConfig(payload)

    return response.json({
      status: 'success',
      data: config,
    })
  }

  public async updatePrivacyConfig({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        is_private: schema.boolean.optional(),
        comment: schema.object.optional().members({
          limit_comments: schema.boolean(),
          limit_values: schema.number(),
        }),
        post: schema.object.optional().members({
          hide_comments: schema.boolean(),
          hide_likes: schema.boolean(),
          hide_views: schema.boolean(),
        }),
        mentions: schema.object.optional().members({
          allow_mentions_from: schema.enum(['all', 'following', 'nobody'] as const),
        }),
      }),
    })

    const config = await this.configurationService.updatePrivacyConfig(payload)

    return response.json({
      status: 'success',
      data: config,
    })
  }

  public async updateSecurityConfig({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        save_login_info: schema.boolean.optional(),
      }),
    })

    const config = await this.configurationService.updateSecurityConfig(payload)

    return response.json({
      status: 'success',
      data: config,
    })
  }
}
