import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema, rules } from '@ioc:Adonis/Core/Validator'
import AuthService from 'App/Services/AuthService'

export default class AuthController {
  private authService = new AuthService()

  public async register({ request, response }: HttpContextContract) {
    const { metadata, ...payload } = await request.validate({
      schema: schema.create({
        email: schema.string({}, [rules.email(), rules.normalizeEmail({ allLowercase: true })]),
        username: schema.string({}, [rules.minLength(6)]),
        password: schema.string({}, [rules.minLength(6)]),
        fullname: schema.string.optional(),
        birthdate: schema.date.optional(),
        gender: schema.enum.optional(['male', 'female'] as const),
        bio: schema.string.optional(),
        metadata: schema.object.optional().members({
          device_name: schema.string({}, [rules.trim()]),
        }),
      }),
    })

    const res = await this.authService.registerWithCredentials(payload, metadata)

    return response.json({
      status: 'success',
      data: res,
    })
  }

  public async login({ request, response }: HttpContextContract) {
    const { metadata, ...payload } = await request.validate({
      schema: schema.create({
        email: schema.string({}, [rules.email(), rules.normalizeEmail({ allLowercase: true })]),
        password: schema.string({}, [rules.minLength(6)]),
        metadata: schema.object.optional().members({
          device_name: schema.string({}, [rules.trim()]),
        }),
      }),
    })

    const res = await this.authService.loginWithCredentials(payload, metadata)

    return response.json({
      status: 'success',
      data: res,
    })
  }

  public async refreshTokenLogin({ request, response, auth }: HttpContextContract) {
    const refreshToken = request.input('refresh_token')
    const credentials = await auth.use('jwt').loginViaRefreshToken(refreshToken)

    return response.json({
      status: 'success',
      data: {
        user: auth.user,
        credentials,
      },
    })
  }

  public async logout({ request, response, auth }: HttpContextContract) {
    const refreshToken = request.input('refresh_token')
    await auth.use('jwt').revoke({ refreshToken })
    return response.json({
      revoke: true,
    })
  }
}
