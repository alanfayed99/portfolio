import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema, rules } from '@ioc:Adonis/Core/Validator'
import LocationService from 'App/Services/LocationService'
import PostService from 'App/Services/PostService'

export default class PostsController {
  private postService = new PostService()
  private locationService = new LocationService()

  public async index({ request, response }: HttpContextContract) {
    const page = request.input('page', 1)
    const limit = request.input('page', 25)

    const posts = await this.postService.getPosts({ page, limit })

    return response.json({
      status: 'success',
      ...posts,
    })
  }

  public async store({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        content: schema.string.optional({ trim: true }),
        visibility: schema.enum(['public', 'close_friend'] as const),
        location_id: schema.string.optional({}, [rules.uuid({ version: 4 })]),
        type: schema.enum(['yuks', 'post'] as const),
        tag_users: schema.string.optional(),
      }),
    })

    const files = request.files('attachments', {
      size: '30mb',
      extnames: ['jpg', 'png', 'mov', 'mp4'],
    })

    if (payload.location_id) {
      await this.locationService.getLocationById(payload.location_id)
    }

    const data = await this.postService.storePost(payload, files)

    return response.created({
      status: 'success',
      data,
    })
  }

  public async update({}: HttpContextContract) {}

  public async destroy({ request, auth, response }: HttpContextContract) {
    await request.validate({
      schema: schema.create({
        params: schema.object().members({
          id: schema.string({}, [rules.uuid({ version: 4 })]),
        }),
      }),
    })

    const userId = auth.user!.id
    await this.postService.destroyPost(request.param('id'), userId)

    response.noContent()
  }

  public async likePost({ request, response }: HttpContextContract) {
    const postId = request.param('id')
    await this.postService.likePost(postId)

    return response.json({
      status: 'success',
    })
  }

  public async unlikePost({ request, response }: HttpContextContract) {
    const postId = request.param('id')
    await this.postService.unlikePost(postId)

    response.noContent()
  }

  public async commentAPost({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        comment: schema.string({
          trim: true,
        }),
        params: schema.object().members({
          id: schema.string({}, [rules.uuid({ version: 4 })]),
        }),
      }),
    })

    const comment = await this.postService.commentPost(payload.params.id, payload.comment)

    return response.created({
      status: 'success',
      data: comment,
    })
  }

  public async getPostComments({ request, response }: HttpContextContract) {
    const page = request.input('page', 1)
    const limit = request.input('page', 25)
    const { params } = await request.validate({
      schema: schema.create({
        params: schema.object().members({
          id: schema.string({}, [rules.uuid({ version: 4 })]),
        }),
      }),
    })

    const comments = await this.postService.getPostComments(params.id, page, limit)

    return response.json({
      status: 'success',
      ...comments,
    })
  }

  public async replyAComment({ request, response }: HttpContextContract) {
    const { params, comment } = await request.validate({
      schema: schema.create({
        comment: schema.string({
          trim: true,
        }),
        params: schema.object().members({
          id: schema.string({}, [rules.uuid({ version: 4 })]),
          commentId: schema.string({}, [rules.uuid({ version: 4 })]),
        }),
      }),
    })

    const reply = await this.postService.replyComment(params.id, params.commentId, comment)

    return response.created({
      status: 'success',
      data: reply,
    })
  }

  public async getCommentReplies({ request, response }: HttpContextContract) {
    const page = request.input('page', 1)
    const limit = request.input('page', 25)
    const { params } = await request.validate({
      schema: schema.create({
        params: schema.object().members({
          id: schema.string({}, [rules.uuid({ version: 4 })]),
          commentId: schema.string({}, [rules.uuid({ version: 4 })]),
        }),
      }),
    })

    const replies = await this.postService.getCommentReplies(params.id, params.commentId, page, limit)

    return response.json({
      status: 'success',
      ...replies,
    })
  }

  public async getUserPosts({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        params: schema.object().members({
          userId: schema.string({}, [rules.uuid({ version: 4 })]),
        }),
        type: schema.enum(['post', 'yuks'] as const),
        page: schema.number.optional(),
        limit: schema.number.optional(),
      }),
    })

    const posts = await this.postService.getUserPosts(payload.params.userId, payload.type, {
      page: payload.page,
      limit: payload.limit,
    })

    return response.json({
      status: 'success',
      ...posts,
    })
  }

  public async bookmarkPost({ request, response }: HttpContextContract) {
    const postId = request.param('id')
    await this.postService.bookmarkPost(postId)

    return response.json({
      status: 'success',
    })
  }

  public async unBookmarkPost({ request, response }: HttpContextContract) {
    const postId = request.param('id')
    await this.postService.unBookmarkPost(postId)

    return response.json({
      status: 'success',
    })
  }
}
