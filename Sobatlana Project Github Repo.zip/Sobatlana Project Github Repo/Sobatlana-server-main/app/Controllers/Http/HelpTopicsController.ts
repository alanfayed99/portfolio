import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import Database from '@ioc:Adonis/Lucid/Database'

export default class HelpTopicsController {
  public async index({ request, response }: HttpContextContract) {
    const lang = request.input('lang', 'en').toLowerCase()
    const data = await Database.rawQuery(
      `SELECT title->>'${lang}' AS title, created_at, updated_at FROM help_topics 
      ORDER BY col_order ASC`
    )

    return response.json({
      status: 'success',
      data: data.rows,
    })
  }

  public async getSubHelpTopics({ request, response }: HttpContextContract) {
    const helpId = request.param('helpId')
    const lang = request.input('lang', 'en').toLowerCase()
    const data = await Database.rawQuery(
      `SELECT title->>'${lang}' AS title, content->>'${lang}' AS content, created_at, updated_at FROM sub_help_topics 
      WHERE help_topic_id = ${helpId} 
      ORDER BY col_order ASC`
    )

    return response.json({
      status: 'success',
      data: data.rows,
    })
  }
}
