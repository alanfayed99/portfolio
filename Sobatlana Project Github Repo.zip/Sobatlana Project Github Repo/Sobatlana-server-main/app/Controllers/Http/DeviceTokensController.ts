import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import DeviceTokenService from 'App/Services/DeviceTokenService'
import { schema } from '@ioc:Adonis/Core/Validator'

export default class DeviceTokensController {
  private deviceTokenService = new DeviceTokenService()

  public async storeMyDeviceToken({ auth, request, response }: HttpContextContract) {
    const user = auth.user!

    const payload = await request.validate({
      schema: schema.create({
        token: schema.string(),
      }),
    })

    await this.deviceTokenService.storeUserDeviceToken(user.id, payload.token)

    return response.json({
      status: 'success',
      message: 'succes register fcm device token',
    })
  }

  public async revokeMyDeviceToken({ auth, request, response }: HttpContextContract) {
    const user = auth.user!
    const reqToken = request.param('token')

    await this.deviceTokenService.removeUserDeviceToken(user.id, reqToken)
    return response.noContent()
  }
}
