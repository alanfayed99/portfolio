import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import PostService from 'App/Services/PostService'

export default class CommentsController {
  private postService = new PostService()

  public async likeComment({ request, response }: HttpContextContract) {
    const commentId = request.param('id')
    await this.postService.likeComment(commentId)

    return response.json({
      status: 'success',
    })
  }

  public async unLikeComment({ request, response }: HttpContextContract) {
    const commentId = request.param('id')
    await this.postService.unLikeComment(commentId)

    return response.json({
      status: 'success',
    })
  }
}
