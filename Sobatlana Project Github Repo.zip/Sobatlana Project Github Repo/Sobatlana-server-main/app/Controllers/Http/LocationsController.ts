import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema } from '@ioc:Adonis/Core/Validator'
import LocationService from 'App/Services/LocationService'
export default class LocationsController {
  private locationService = new LocationService()

  public async searchLocation({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        search: schema.string(),
      }),
    })

    const locations = await this.locationService.searchLocation(payload.search)
    const data = locations.map((loc) => ({
      id: loc.id,
      name: loc.name,
      place_id: loc.place_id,
      formatted_address: loc.formatted_address,
    }))

    return response.json({
      status: 'success',
      data,
    })
  }
}
