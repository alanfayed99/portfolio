import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { schema, rules } from '@ioc:Adonis/Core/Validator'
import InterestList from 'App/Models/InterestList'
import User from 'App/Models/User'
import PostService from 'App/Services/PostService'
import SocialService from 'App/Services/SocialService'
import UserService from 'App/Services/UserService'
import Helpers from 'App/Utils/Helpers'

export default class UsersController {
  private userService = new UserService()
  private socialService = new SocialService()
  private postService = new PostService()
  private userIdSchema = schema.create({
    params: schema.object().members({
      userId: schema.string({}, [rules.uuid({ version: 4 })]),
    }),
  })

  public async getMyProfile({ response, auth }: HttpContextContract) {
    const user = await User.findOrFail(auth.user!.id)
    const data = await Helpers.preComputeAsset(user, ['photo', 'background_cover'])

    return response.json({
      status: 'success',
      data,
    })
  }

  public async updateUser({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        username: schema.string.optional(),
        fullname: schema.string.optional(),
        birthdate: schema.date.optional(),
        gender: schema.enum.optional(['male', 'female'] as const),
        bio: schema.string.nullableAndOptional(),
      }),
    })

    const user = await this.userService.updateUser(payload)

    return response.json({
      status: 'success',
      data: user,
    })
  }

  public async addMyInterest({ request, response, auth }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        interestIds: schema.array().members(schema.number()),
      }),
    })

    const interests = await InterestList.query().whereIn('id', payload.interestIds)
    await auth.user?.related('interests').sync(
      interests.map((model) => model.id),
      false
    )

    return response.json({
      status: 'success',
    })
  }

  public async updatePassword({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: schema.create({
        current_password: schema.string(),
        password: schema.string([rules.minLength(5), rules.confirmed()]),
      }),
    })

    await this.userService.updatePassword(payload.current_password, payload.password)

    return response.json({
      status: 'success',
    })
  }

  public async followUser({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: this.userIdSchema,
    })

    await this.socialService.followUser(payload.params.userId)

    return response.json({
      status: 'success',
    })
  }

  public async unfollowUser({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: this.userIdSchema,
    })

    await this.socialService.unfollowUser(payload.params.userId)

    return response.json({
      status: 'success',
    })
  }

  public async removeMyFollower({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: this.userIdSchema,
    })

    await this.socialService.removeMyFollower(payload.params.userId)

    return response.json({
      status: 'success',
    })
  }

  public async getMyStats({ response, auth }: HttpContextContract) {
    const data = await this.userService.getUserStats(auth.user!)

    return response.json({
      status: 'success',
      data,
    })
  }

  public async getUserStats({ request, response }: HttpContextContract) {
    const payload = await request.validate({
      schema: this.userIdSchema,
    })

    const data = await this.userService.getUserStats(payload.params.userId)

    return response.json({
      status: 'success',
      data,
    })
  }

  public async getMyPosts({ request, response, auth }: HttpContextContract) {
    const user = auth.user!
    const payload = await request.validate({
      schema: schema.create({
        type: schema.enum(['post', 'yuks'] as const),
        page: schema.number.optional(),
        limit: schema.number.optional(),
      }),
    })

    const posts = await this.postService.getUserPosts(user.id, payload.type, {
      page: payload.page,
      limit: payload.limit,
    })

    return response.json({
      status: 'success',
      ...posts,
    })
  }
}
