import HttpErrorException from 'App/Exceptions/HttpErrorException'
import User from 'App/Models/User'
import BaseService from './BaseService'
import FCMService from './FCMService'

export default class SocialService extends BaseService {
  private fcmService = new FCMService()

  public async followUser(userId: string) {
    const { user } = this.getCtx()

    if (userId === user.id) {
      throw new HttpErrorException('Cannot use own userId', 400)
    }

    const newFollowing = await User.query()
      .where('id', userId)
      .preload('followers', (query) => query.where('follower_id', user.id))
      .firstOrFail()

    const isFollowedBefore = !!newFollowing.followers[0]

    if (!isFollowedBefore) {
      await user.related('following').sync([newFollowing.id], false)
      this.fcmService.publishDeviceNotification({
        type: 'follow',
        model: newFollowing,
        targetUserId: newFollowing.id,
      })
    }
  }

  public async getMyFollower() {}

  public async unfollowUser(userId: string) {
    const { user } = this.getCtx()

    if (userId === user.id) {
      throw new HttpErrorException('Cannot use own userId', 400)
    }
    await user.related('following').detach([userId])
  }

  public async removeMyFollower(userId: string) {
    const { user } = this.getCtx()

    if (userId === user.id) {
      throw new HttpErrorException('Cannot use own userId', 400)
    }
    await user.related('followers').detach([userId])
  }
}
