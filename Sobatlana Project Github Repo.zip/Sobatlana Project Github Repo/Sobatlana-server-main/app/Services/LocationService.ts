import HttpErrorException from 'App/Exceptions/HttpErrorException'
import Location from 'App/Models/Location'
import MapsTransformer from 'App/Transformer/MapsTransformer'
import { StoreLocationPayload } from 'App/Types/Location'
import MapsService from './MapsService'

class LocationService {
  private mapsService = new MapsService()

  /**
   * Search Location / places from gmaps and input to local datastores
   *
   * @param input {string}
   * @returns {Promise<Location[]>}
   */
  public async searchLocation(input: string): Promise<Location[]> {
    let results: Location[] = []
    const locations = await Location.query().whereRaw(`LOWER(name) LIKE '%${input}%'`)
    results = [...locations]

    if (locations.length === 0) {
      const gmapPlaces = await this.mapsService.findPlace(input)
      const data = await this.storeLocations(MapsTransformer.transformMapsToLocations(gmapPlaces))
      results = results.concat(data)
      results = [...new Map(results.map((res) => [res.place_id, res])).values()]
    }

    return results
  }

  public async storeLocations(payloads: StoreLocationPayload[]) {
    const locations = await Location.fetchOrCreateMany('place_id', payloads)

    return locations
  }

  public async getLocationById(id: string) {
    const location = await Location.find(id)
    if (!location) {
      throw new HttpErrorException('Location not found', 404)
    }
  }
}

export default LocationService
