import { MultipartFileContract } from '@ioc:Adonis/Core/BodyParser'
import { Attachment } from '@ioc:Adonis/Addons/AttachmentLite'
import { GetPostsParams, PostType, StorePost } from 'App/Types/Post'
import Post from 'App/Models/Post'
import Helpers from 'App/Utils/Helpers'
import User from 'App/Models/User'
import Comment from 'App/Models/Comment'
import FCMService from './FCMService'
import BaseService from './BaseService'

export default class PostService extends BaseService {
  private fcmService = new FCMService()

  public async getPosts({ page, limit }: GetPostsParams) {
    const { user } = this.getCtx()

    let posts = await Post.query()
      .where('visibility', 'public')
      .orderBy('created_at', 'desc')
      .preload('location', (query) => query.select('name'))
      .preload('user', (query) => query.select('fullname', 'username', 'photo'))
      .preload('attachments', (query) => query.select('media'))
      .preload('likes', (query) => query.where('user_id', user.id))
      .preload('tags', (query) => query.select('username', 'fullname'))
      .preload('bookmarksBy', (query) => query.where('user_id', user.id))
      .withCount('likes')
      .withCount('comments')
      .paginate(page, limit)

    return Helpers.simplifyPagination(
      posts.getMeta(),
      posts.all().map((post) => ({
        ...post.toJSON(),
        likes: undefined,
        bookmarksBy: undefined,
        isLiked: !!post.likes[0],
        isBookmarked: !!post.bookmarksBy[0],
        total_likes: Number(post.$extras.likes_count),
        total_comment: Number(post.$extras.comments_count),
      }))
    )
  }

  public async storePost(payload: StorePost, files: MultipartFileContract[]) {
    const { user } = this.getCtx()
    const { tag_users: tagUsers, ...body } = payload

    const post = await Post.create({ ...body, user_id: user.id })
    const newAttachments = files.map((file) => ({ user_id: user.id, media: Attachment.fromFile(file) }))
    await post.related('attachments').createMany(newAttachments)

    if (tagUsers) {
      const tagUserModels = await User.query().whereIn('username', tagUsers.split(','))
      await post.related('tags').attach(tagUserModels.map((model) => model.id))
    }

    return post
  }

  public async destroyPost(postId: string, userId: string) {
    const post = await Post.query().where('id', postId).andWhere('user_id', userId).firstOrFail()
    await post.delete()
  }

  public async likePost(postId: string) {
    const { user } = this.getCtx()
    const post = await Post.query()
      .where('id', postId)
      .preload('likes', (query) => query.where('user_id', user.id).select('id'))
      .firstOrFail()
    const isLikedBefore = !!post.likes[0]

    if (!isLikedBefore) {
      await post?.related('likes').sync([user.id], false)
      this.fcmService.publishDeviceNotification({
        type: 'like',
        postType: post.type,
        targetUserId: post.user_id,
        model: post,
      })
    }
  }

  public async unlikePost(postId: string) {
    const { user } = this.getCtx()
    const post = await Post.findOrFail(postId)
    await post?.related('likes')?.detach([user.id])
  }

  public async commentPost(postId: string, content: string) {
    const { user } = this.getCtx()
    const post = await Post.findOrFail(postId)
    const comment = await post.related('comments').create({
      user_id: user.id,
      comment: content,
    })

    return comment
  }

  public async getPostComments(postId: string, page: number, limit: number) {
    const { user } = this.getCtx()
    const post = await Post.findOrFail(postId)
    const comments = await post
      .related('comments')
      .query()
      .preload('user', (query) => query.select('username', 'photo'))
      .preload('likes', (query) => query.where('user_id', user.id))
      .withCount('replies')
      .paginate(page, limit)

    return Helpers.simplifyPagination(
      comments.getMeta(),
      comments.all().map((comment) => ({
        ...comment.toJSON(),
        likes: undefined,
        is_liked: !!comment.likes[0],
        total_replies: Number(comment.$extras.replies_count),
      }))
    )
  }

  public async replyComment(postId: string, commentId: string, content: string) {
    const { user } = this.getCtx()
    const comment = await Comment.query().where('post_id', postId).andWhere('id', commentId).firstOrFail()
    const reply = await comment.related('replies').create({
      user_id: user.id,
      comment: content,
    })

    return reply
  }

  public async getCommentReplies(postId: string, commentId: string, page: number, limit: number) {
    const comment = await Comment.query().where('post_id', postId).andWhere('id', commentId).firstOrFail()
    const replies = await comment
      .related('replies')
      .query()
      .preload('user', (query) => query.select('username', 'photo'))
      .paginate(page, limit)

    return Helpers.simplifyPagination(replies.getMeta(), replies.all())
  }

  public async getUserPosts(userId: string, type: PostType, params?: Partial<GetPostsParams>) {
    const page = params?.page || 1
    const limit = params?.limit || 25
    const isYuks = type === 'yuks'

    let postQuery = Post.query()
      .where('user_id', userId)
      .andWhere('type', type)
      .orderBy('created_at', 'desc')
      .preload('attachments', (query) => query.select('media'))

    if (type === 'post') {
      postQuery
        .preload('location', (query) => query.select('name'))
        .preload('user', (query) => query.select('fullname', 'username', 'photo'))
        .preload('likes', (query) => query.where('user_id', userId))
        .preload('tags', (query) => query.select('username', 'fullname'))
        .withCount('likes')
        .withCount('comments')
    }

    const posts = await postQuery.paginate(page, limit)

    return Helpers.simplifyPagination(
      posts.getMeta(),
      posts.all().map((post) => ({
        ...post.toJSON(),
        likes: undefined,
        isLiked: isYuks ? null : !!post.likes[0],
        total_likes: isYuks ? null : Number(post.$extras.likes_count),
        total_comment: isYuks ? null : Number(post.$extras.comments_count),
      }))
    )
  }

  public async likeComment(commentId: string) {
    const { user } = this.getCtx()
    const comment = await Comment.findOrFail(commentId)
    await comment.related('likes').sync([user.id], false)
  }

  public async unLikeComment(commentId: string) {
    const { user } = this.getCtx()
    const comment = await Comment.findOrFail(commentId)
    await comment.related('likes').detach([user.id])
  }

  public async bookmarkPost(postId: string) {
    const { user } = this.getCtx()
    const post = await Post.findOrFail(postId)

    await user.related('bookmarks').sync([post.id], false)
  }

  public async unBookmarkPost(postId: string) {
    const { user } = this.getCtx()
    const post = await Post.findOrFail(postId)

    await user.related('bookmarks').detach([post.id])
  }
}
