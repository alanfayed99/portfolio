import Hash from '@ioc:Adonis/Core/Hash'
import { Attachment } from '@ioc:Adonis/Addons/AttachmentLite'
import HttpErrorException from 'App/Exceptions/HttpErrorException'
import Helpers from 'App/Utils/Helpers'
import User from 'App/Models/User'
import BaseService from './BaseService'

export default class UserService extends BaseService {
  public async updateUser(payload) {
    const { auth, request } = this.getCtx()
    const files = {
      photo: request.file('photo', {
        size: '2mb',
        extnames: ['jpg', 'png'],
      }),
      background_cover: request.file('background_cover', {
        size: '2mb',
        extnames: ['jpg', 'png'],
      }),
    }

    const uploadAssetKey = Object.keys(files).filter((key) => !!files[key])
    await auth.user?.save()
    if (uploadAssetKey.length) {
      uploadAssetKey.forEach((key) => {
        payload[key] = Attachment.fromFile(files[key])
      })
    }

    const data = await auth.user!.merge(payload).save()
    return data
  }

  public async updatePassword(currentPassword: string, newPassword: string) {
    const { user } = this.getCtx()

    const checkPass = await Hash.verify(user.password, currentPassword)
    if (!checkPass) {
      throw new HttpErrorException("Current password didn't match")
    }

    user.password = newPassword
    await user.save()

    return user
  }

  public async getUserStats(baseUser: string | User) {
    let user: User

    if (baseUser instanceof User) {
      user = baseUser
    } else {
      user = await User.findOrFail(baseUser)
    }

    await user.load('interests')
    await user.loadCount('followers').loadCount('following').loadCount('posts')

    const stats = {
      total_followers: user.$extras.followers_count,
      total_followings: user.$extras.following_count,
      total_posts: user.$extras.posts_count,
    }

    const result = await Helpers.preComputeAsset(user, ['photo', 'background_cover'])
    result.stats = stats
    result.joined_at = user.createdAt

    return Object.assign(result)
  }
}
