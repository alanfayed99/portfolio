import axios from 'axios'
import Logger from '@ioc:Adonis/Core/Logger'
import Env from '@ioc:Adonis/Core/Env'

class MapsService {
  private baseUrl = 'https://maps.googleapis.com/maps/api'
  private key = Env.get('GMAPS_API_KEY')

  public async findPlace(input: string) {
    const res = await axios.get(this.baseUrl.concat('/place/findplacefromtext/json'), {
      params: {
        key: this.key,
        input,
        inputtype: 'textquery',
        fields: 'name,geometry,formatted_address,place_id,type',
      },
    })

    Logger.info(`findPlace >> ${input} >> status: ${res.status}`)
    return res.data.candidates
  }
}

export default MapsService
