import NotificationConfiguration from 'App/Models/NotificationConfiguration'
import PrivacyConfiguration from 'App/Models/PrivacyConfiguration'
import SecurityConfiguration from 'App/Models/SecurityConfiguration'
import {
  UpdateNotificationConfigPayload,
  UpdatePrivacyConfigPayload,
  UpdateSecurityConfig,
} from 'App/Types/Configuration'
import BaseService from './BaseService'

class ConfigurationService extends BaseService {
  public async getNotificationConfig() {
    const { user } = this.getCtx()
    const notifConfig = await NotificationConfiguration.findByOrFail('user_id', user.id)
    return notifConfig
  }

  public async getPrivacyConfig() {
    const { user } = this.getCtx()
    const privacyConfig = await PrivacyConfiguration.findByOrFail('user_id', user.id)
    return privacyConfig
  }

  public async updateNotificationConfig(payload: UpdateNotificationConfigPayload) {
    const { user } = this.getCtx()
    const notifConfig = await NotificationConfiguration.findByOrFail('user_id', user.id)
    await notifConfig.merge(payload).save()

    return notifConfig
  }

  public async updatePrivacyConfig(payload: UpdatePrivacyConfigPayload) {
    const { user } = this.getCtx()
    const privacyConfig = await PrivacyConfiguration.findByOrFail('user_id', user.id)
    await privacyConfig.merge(payload).save()
    return privacyConfig
  }

  public async getSecurityConfig() {
    const { user } = this.getCtx()
    const securityConfig = await SecurityConfiguration.query()
      .where('user_id', user.id)
      .preload('login_activities', (query) => {
        query.groupLimit(5)
        query.groupOrderBy('login_activities.created_at', 'desc')
      })
      .firstOrFail()

    return securityConfig
  }

  public async updateSecurityConfig(payload: UpdateSecurityConfig) {
    const { user } = this.getCtx()
    const securityConfig = await SecurityConfiguration.query().where('user_id', user.id).firstOrFail()
    await securityConfig.merge(payload).save()

    return securityConfig
  }
}

export default ConfigurationService
