import geoip from 'fast-geoip'
import HttpErrorException from 'App/Exceptions/HttpErrorException'
import Database from '@ioc:Adonis/Lucid/Database'
import Hash from '@ioc:Adonis/Core/Hash'
import User from 'App/Models/User'
import { LoginMetadata, LoginPayload, RegisterMetadata, RegisterPayload } from 'App/Types/Auth'
import BaseService from './BaseService'

export default class AuthService extends BaseService {
  public async loginWithCredentials(payload: LoginPayload, metadata?: LoginMetadata) {
    const { auth, request } = this.getCtx()
    const geo = await geoip.lookup(request.ip())

    const user = await User.findBy('email', payload.email)
    if (!user) {
      throw new HttpErrorException('Email or password is incorrect', 400)
    }

    if (!(await Hash.verify(user.password, payload.password))) {
      // not verified
      throw new HttpErrorException('Email or password is incorrect', 400)
    }

    await Database.transaction(async (trx) => {
      user.useTransaction(trx)
      const [securityConfig] = await Promise.all([
        user.related('securityConfig').firstOrCreate({}),
        user.related('notificationConfig').firstOrCreate({}),
        user.related('privacyConfig').firstOrCreate({}),
      ])

      securityConfig.useTransaction(trx)
      await securityConfig.related('login_activities').create({
        device_name: metadata?.device_name,
        country: geo?.country,
        city: geo?.city,
        lat: geo?.ll[0],
        long: geo?.ll[1],
      })
    })

    const credentials = await auth.use('jwt').generate(user)

    return {
      user,
      credentials,
    }
  }

  public async registerWithCredentials(payload: RegisterPayload, metadata?: RegisterMetadata) {
    const { auth, request } = this.getCtx()
    const geo = await geoip.lookup(request.ip())

    const checkEmail = await User.findBy('email', payload.email)
    if (checkEmail) {
      throw new HttpErrorException('user already registered', 400)
    }

    const checkUsername = await User.findBy('username', payload.username)
    if (checkUsername) {
      throw new HttpErrorException('username already exist', 400)
    }

    let user = new User()

    await Database.transaction(async (trx) => {
      user.merge(payload)

      user.useTransaction(trx)
      await user.save()
      const [securityConfig] = await Promise.all([
        user.related('securityConfig').create({}),
        user.related('notificationConfig').create({}),
        user.related('privacyConfig').create({}),
      ])

      securityConfig.useTransaction(trx)
      await securityConfig.related('login_activities').create({
        device_name: metadata?.device_name,
        country: geo?.country,
        city: geo?.city,
        lat: geo?.ll[0],
        long: geo?.ll[1],
      })
    })

    const credentials = await auth.use('jwt').generate(user)

    return {
      user,
      credentials,
    }
  }
}
