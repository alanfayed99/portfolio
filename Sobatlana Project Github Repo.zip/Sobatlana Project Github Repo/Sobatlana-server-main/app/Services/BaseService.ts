import HttpContext, { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

abstract class BaseService {
  protected getCtx() {
    const { auth, ...rest } = HttpContext.get() as HttpContextContract
    const user = auth.user!

    return { user, auth, ...rest }
  }
}

export default BaseService
