import { messaging } from 'firebase-admin'
// import Redis from '@ioc:Adonis/Addons/Redis'
import HttpContext, { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import { PublishNotificationPayload, SubsNotificationPayload } from 'App/Types/Notification'
import User from 'App/Models/User'
import Notification from 'App/Models/Notification'
import DeviceTokenService from 'App/Services/DeviceTokenService'
import DeviceToken from 'App/Models/DeviceToken'

export default class FCMService {
  private deviceTokenService = new DeviceTokenService()

  public async sendNotifViaDevice(message: any, deviceToken: DeviceToken[]) {
    const registrationTokens = deviceToken.map((device) => device.token)
    return messaging().sendMulticast({ data: message, tokens: registrationTokens })
  }

  public async publishDeviceNotification(payload: PublishNotificationPayload) {
    const { auth } = HttpContext.get() as HttpContextContract
    let targetUser: User
    const currentUser = auth.user!

    if (currentUser.id === payload.targetUserId) {
      targetUser = currentUser
      return
    } else {
      targetUser = await User.findOrFail(payload.targetUserId)
    }

    this.subsDeviceNotification({
      ...payload,
      currentUser,
      targetUser,
    })

    // disable redish publish, using directly
    // Redis.publish(
    //   'fcm:publish',
    //   JSON.stringify({
    //     ...payload,
    //     currentUser,
    //     targetUser,
    //   })
    // )
  }

  public async subsDeviceNotification({ type, postType, currentUser, targetUser, model }: SubsNotificationPayload) {
    let content: string | undefined
    let postRelatedId: string | undefined

    switch (type) {
      case 'like':
        content = `${currentUser?.username} liked your ${postType}`
        postRelatedId = model?.id || null
        break

      case 'follow':
        content = `${currentUser?.username} started following you`
        break

      default:
        break
    }

    if (!content) return

    const userDeviceTokenPromise = this.deviceTokenService.getUserDeviceToken(targetUser.id)
    const notifPromise = Notification.create({
      content,
      type,
      user_id: targetUser.id,
      user_related: currentUser.id,
      post_related_id: postRelatedId,
    })
    const [notifHistory, userDeviceToken] = await Promise.all([notifPromise, userDeviceTokenPromise])
    const notifPayload = notifHistory.toJSON()

    if (!userDeviceToken.length) return

    // remove undefined property
    Object.keys(notifPayload).forEach((key) => {
      if (notifPayload[key] === undefined) {
        delete notifPayload[key]
      }
    })

    return this.sendNotifViaDevice(notifPayload, userDeviceToken)
  }
}
