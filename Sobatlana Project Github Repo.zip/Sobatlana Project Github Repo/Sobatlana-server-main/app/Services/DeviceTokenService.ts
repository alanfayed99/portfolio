import DeviceToken from 'App/Models/DeviceToken'

export default class DeviceTokenService {
  public async getUserDeviceToken(userId: string) {
    return DeviceToken.query().where('user_id', userId)
  }

  public async storeUserDeviceToken(userId: string, token: string) {
    const checkExist = await DeviceToken.query().where('token', token).andWhere('user_id', userId).first()
    if (!checkExist) {
      await DeviceToken.create({
        user_id: userId,
        token,
      })
    }
  }

  public async removeUserDeviceToken(userId: string, token: string) {
    return DeviceToken.query().where('user_id', userId).andWhere('token', token).delete()
  }
}
