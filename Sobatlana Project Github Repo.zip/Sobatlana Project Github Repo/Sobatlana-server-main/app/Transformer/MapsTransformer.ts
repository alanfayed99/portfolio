import { StoreLocationPayload } from 'App/Types/Location'

export default class MapsTransformer {
  public static transformMapToLocation(payload: Record<string, any>): StoreLocationPayload {
    return {
      name: payload.name,
      place_id: payload.place_id,
      formatted_address: payload.formatted_address,
      lat: payload.geometry.location.lat,
      long: payload.geometry.location.lng,
      viewport: payload.geometry,
    }
  }

  public static transformMapsToLocations(payloads: Record<string, any>[]): StoreLocationPayload[] {
    return payloads.map((payload) => MapsTransformer.transformMapToLocation(payload))
  }
}
