import User from 'App/Models/User'
import { PostType } from './Post'

export type NotifType = 'follow' | 'like' | 'mentioned' | 'personal'

export interface PublishNotificationPayload {
  type: NotifType
  model: any
  postType?: PostType
  targetUserId: string
}

export interface SubsNotificationPayload {
  type?: NotifType
  model?: any
  postType?: PostType
  currentUser: User
  targetUser: User
  targetUserId: string
}
