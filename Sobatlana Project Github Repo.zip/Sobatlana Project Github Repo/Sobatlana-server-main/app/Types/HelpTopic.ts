export type HelpTopicTitle = { id: string; en: string }
export type HelpTopicContent = { id: string; en: string }
