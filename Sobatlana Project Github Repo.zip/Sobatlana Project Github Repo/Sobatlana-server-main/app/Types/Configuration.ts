export interface NotificationMessageConfig {
  new_message: boolean
  message_request: boolean
}

export interface NotificationPeopleConfig {
  new_follower: boolean
  recommendation: boolean
  follow_request: boolean
}

export interface NotificationInteractionConfig {
  post_liked: boolean
  new_comment: boolean
  comment_liked: boolean
  name_mentioned: boolean
  account_tagged: boolean
}

export interface NotificationSecurityConfig {
  password_changed: boolean
  new_login: boolean
}

export interface UpdateNotificationConfigPayload {
  message?: NotificationMessageConfig
  people?: NotificationPeopleConfig
  interaction?: NotificationInteractionConfig
  security?: NotificationSecurityConfig
}

export interface PrivacyCommentConfig {
  limit_comments: boolean
  limit_values: number
}

export interface PrivacyPostConfig {
  hide_comments: boolean
  hide_likes: boolean
  hide_views: boolean
}

export interface PrivacyMentionsConfig {
  allow_mentions_from: 'all' | 'following' | 'nobody'
}

export interface UpdatePrivacyConfigPayload {
  is_private?: boolean
  comment?: PrivacyCommentConfig
  post?: PrivacyPostConfig
  mentions?: PrivacyMentionsConfig
}

export interface UpdateSecurityConfig {
  save_login_info?: boolean
}
