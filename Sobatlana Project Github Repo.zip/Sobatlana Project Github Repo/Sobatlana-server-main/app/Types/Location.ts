export interface ViewportField {
  northeast: {
    lat: number
    lng: number
  }
  southwest: {
    lat: number
    lng: number
  }
}

export interface StoreLocationPayload {
  name: string
  place_id: string
  formatted_address: string
  lat: number
  long: number
  viewport?: ViewportField
}
