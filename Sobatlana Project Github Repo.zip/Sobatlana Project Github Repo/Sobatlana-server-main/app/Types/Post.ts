export type PostVisibility = 'close_friend' | 'public'
export type PostType = 'yuks' | 'post'
export interface StorePost {
  content?: string
  visibility: PostVisibility
  location_id?: string
  type: PostType
  tag_users?: string
}

export interface GetPostsParams {
  page: number
  limit: number
}
