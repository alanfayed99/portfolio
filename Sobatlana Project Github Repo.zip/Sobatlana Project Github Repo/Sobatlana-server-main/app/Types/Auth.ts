import { DateTime } from 'luxon'

export interface LoginPayload {
  email: string
  password: string
}

export interface LoginMetadata {
  device_name?: string
}

export interface RegisterPayload {
  username: string
  email: string
  password: string
  fullname?: string
  birthdate?: DateTime
  gender?: 'male' | 'female'
  bio?: string
}

export interface RegisterMetadata {
  device_name?: string
}
