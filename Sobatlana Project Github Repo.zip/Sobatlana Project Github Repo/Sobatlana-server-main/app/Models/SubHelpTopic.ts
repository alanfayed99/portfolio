import { DateTime } from 'luxon'
import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'
import { HelpTopicContent, HelpTopicTitle } from 'App/Types/HelpTopic'

export default class SubHelpTopic extends BaseModel {
  @column({ isPrimary: true })
  public id: number

  @column()
  public col_order?: number

  @column()
  public help_topic_id: number

  @column()
  public title: HelpTopicTitle

  @column()
  public content: HelpTopicContent

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
