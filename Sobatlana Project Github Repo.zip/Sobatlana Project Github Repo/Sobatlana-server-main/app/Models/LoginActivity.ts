import { DateTime } from 'luxon'
import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'

export default class LoginActivity extends BaseModel {
  @column({ isPrimary: true })
  public id: string

  @column()
  public security_config_id: string

  @column()
  public device_name?: string

  @column()
  public city?: string

  @column()
  public country?: string

  @column()
  public lat?: number

  @column()
  public long?: number

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
