import { DateTime } from 'luxon'
import {
  BaseModel,
  BelongsTo,
  belongsTo,
  column,
  HasMany,
  hasMany,
  ManyToMany,
  manyToMany,
} from '@ioc:Adonis/Lucid/Orm'
import User from 'App/Models/User'
import Location from 'App/Models/Location'
import Attachment from 'App/Models/Attachment'
import { PostType, PostVisibility } from 'App/Types/Post'
import Comment from './Comment'

export default class Post extends BaseModel {
  @belongsTo(() => User, {
    foreignKey: 'user_id',
  })
  public user: BelongsTo<typeof User>

  @belongsTo(() => Location, {
    foreignKey: 'location_id',
  })
  public location: BelongsTo<typeof Location>

  @hasMany(() => Attachment, {
    foreignKey: 'post_id',
  })
  public attachments: HasMany<typeof Attachment>

  @manyToMany(() => User, {
    pivotForeignKey: 'post_id',
    pivotRelatedForeignKey: 'user_id',
    pivotTable: 'likes',
    pivotTimestamps: true,
  })
  public likes: ManyToMany<typeof User>

  @hasMany(() => Comment, {
    foreignKey: 'post_id',
  })
  public comments: HasMany<typeof Comment>

  @manyToMany(() => User, {
    pivotTable: 'post_tags',
    pivotForeignKey: 'post_id',
    pivotRelatedForeignKey: 'user_id',
  })
  public tags: ManyToMany<typeof User>

  @manyToMany(() => User, {
    pivotTable: 'bookmarks',
    pivotForeignKey: 'post_id',
    pivotRelatedForeignKey: 'user_id',
  })
  public bookmarksBy: ManyToMany<typeof User>

  @column({ isPrimary: true })
  public id: string

  @column()
  public user_id: string

  @column()
  public content: string

  @column()
  public visibility: PostVisibility

  @column()
  public location_id?: string

  @column()
  public type: PostType

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
