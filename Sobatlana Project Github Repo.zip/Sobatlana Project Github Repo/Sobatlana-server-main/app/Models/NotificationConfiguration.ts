import { DateTime } from 'luxon'
import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'
import {
  NotificationInteractionConfig,
  NotificationMessageConfig,
  NotificationPeopleConfig,
  NotificationSecurityConfig,
} from 'App/Types/Configuration'

export default class NotificationConfiguration extends BaseModel {
  @column({ isPrimary: true })
  public id: number

  @column()
  public user_id: string

  @column()
  public message: NotificationMessageConfig

  @column()
  public people: NotificationPeopleConfig

  @column()
  public interaction: NotificationInteractionConfig

  @column()
  public security: NotificationSecurityConfig

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
