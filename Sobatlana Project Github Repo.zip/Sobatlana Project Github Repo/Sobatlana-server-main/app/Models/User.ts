import { DateTime } from 'luxon'
import Hash from '@ioc:Adonis/Core/Hash'
import {
  column,
  beforeSave,
  BaseModel,
  manyToMany,
  ManyToMany,
  hasMany,
  HasMany,
  hasOne,
  HasOne,
} from '@ioc:Adonis/Lucid/Orm'
import { attachment, AttachmentContract } from '@ioc:Adonis/Addons/AttachmentLite'
import Post from 'App/Models/Post'
import InterestList from 'App/Models/InterestList'
import NotificationConfiguration from 'App/Models/NotificationConfiguration'
import PrivacyConfiguration from 'App/Models/PrivacyConfiguration'
import SecurityConfiguration from 'App/Models/SecurityConfiguration'
import DeviceToken from './DeviceToken'

export default class User extends BaseModel {
  @hasMany(() => Post, {
    foreignKey: 'user_id',
  })
  public posts: HasMany<typeof Post>

  @hasOne(() => NotificationConfiguration, {
    foreignKey: 'user_id',
  })
  public notificationConfig: HasOne<typeof NotificationConfiguration>

  @hasOne(() => PrivacyConfiguration, {
    foreignKey: 'user_id',
  })
  public privacyConfig: HasOne<typeof PrivacyConfiguration>

  @hasOne(() => SecurityConfiguration, {
    foreignKey: 'user_id',
  })
  public securityConfig: HasOne<typeof SecurityConfiguration>

  @manyToMany(() => User, {
    pivotForeignKey: 'following_id',
    pivotRelatedForeignKey: 'follower_id',
    pivotTable: 'user_relations',
    pivotTimestamps: true,
  })
  public followers: ManyToMany<typeof User>

  @manyToMany(() => User, {
    pivotForeignKey: 'follower_id',
    pivotRelatedForeignKey: 'following_id',
    pivotTable: 'user_relations',
    pivotTimestamps: true,
  })
  public following: ManyToMany<typeof User>

  @hasMany(() => DeviceToken, {
    foreignKey: 'user_id',
  })
  public deviceTokens: HasMany<typeof DeviceToken>

  @manyToMany(() => Post, {
    pivotTable: 'bookmarks',
    pivotForeignKey: 'user_id',
    pivotRelatedForeignKey: 'post_id',
    pivotTimestamps: true,
  })
  public bookmarks: ManyToMany<typeof Post>

  @column({ isPrimary: true })
  public id: string

  @column()
  public email: string

  @column({ serializeAs: null })
  public password: string

  @column()
  public role: 'admin' | 'user'

  @column()
  public rememberMeToken?: string

  @column()
  public username: string

  @column()
  public fullname?: string

  @column.dateTime()
  public birthdate?: DateTime

  @column()
  public gender?: 'male' | 'female'

  @column()
  public bio?: string | null

  @attachment()
  public photo?: AttachmentContract

  @attachment()
  public background_cover?: AttachmentContract

  @column({ serializeAs: null })
  public google_auth_id?: string

  @column({ serializeAs: null })
  public apple_auth_id?: string

  @manyToMany(() => InterestList, {
    pivotTable: 'my_interests',
  })
  public interests: ManyToMany<typeof InterestList>

  @column.dateTime({ autoCreate: true, serializeAs: null })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true, serializeAs: null })
  public updatedAt: DateTime

  @beforeSave()
  public static async hashPassword(user: User) {
    if (user.$dirty.password) {
      user.password = await Hash.make(user.password)
    }
  }
}
