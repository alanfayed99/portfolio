import { DateTime } from 'luxon'
import {
  BaseModel,
  BelongsTo,
  belongsTo,
  column,
  HasMany,
  hasMany,
  manyToMany,
  ManyToMany,
} from '@ioc:Adonis/Lucid/Orm'
import User from 'App/Models/User'
import CommentReply from 'App/Models/CommentReply'

export default class Comment extends BaseModel {
  @belongsTo(() => User, {
    foreignKey: 'user_id',
  })
  public user: BelongsTo<typeof User>

  @hasMany(() => CommentReply, {
    foreignKey: 'comment_id',
  })
  public replies: HasMany<typeof CommentReply>

  @manyToMany(() => User, {
    pivotForeignKey: 'comment_id',
    pivotRelatedForeignKey: 'user_id',
    pivotTable: 'comment_likes',
    pivotTimestamps: true,
  })
  public likes: ManyToMany<typeof User>

  @column({ isPrimary: true })
  public id: string

  @column()
  public user_id: string

  @column()
  public post_id: string

  @column()
  public comment: string

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
