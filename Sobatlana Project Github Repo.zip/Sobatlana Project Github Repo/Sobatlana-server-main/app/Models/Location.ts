import { DateTime } from 'luxon'
import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'
import { ViewportField } from 'App/Types/Location'

export default class Location extends BaseModel {
  @column({ isPrimary: true })
  public id: string

  @column()
  public name: string

  @column()
  public place_id: string

  @column()
  public formatted_address: string

  @column()
  public lat: number

  @column()
  public long: number

  @column()
  public viewport?: ViewportField

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
