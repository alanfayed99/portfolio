import { DateTime } from 'luxon'
import { BaseModel, column } from '@ioc:Adonis/Lucid/Orm'
import { PrivacyCommentConfig, PrivacyMentionsConfig, PrivacyPostConfig } from 'App/Types/Configuration'

export default class PrivacyConfiguration extends BaseModel {
  @column({ isPrimary: true })
  public id: string

  @column()
  public user_id: string

  @column()
  public is_private: boolean

  @column()
  public comment: PrivacyCommentConfig

  @column()
  public post: PrivacyPostConfig

  @column()
  public mentions: PrivacyMentionsConfig

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
