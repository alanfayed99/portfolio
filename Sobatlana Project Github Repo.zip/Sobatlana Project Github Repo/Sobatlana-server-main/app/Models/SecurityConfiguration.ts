import { DateTime } from 'luxon'
import { BaseModel, column, HasMany, hasMany } from '@ioc:Adonis/Lucid/Orm'
import LoginActivity from './LoginActivity'

export default class SecurityConfiguration extends BaseModel {
  @hasMany(() => LoginActivity, {
    foreignKey: 'security_config_id',
  })
  public login_activities: HasMany<typeof LoginActivity>

  @column({ isPrimary: true })
  public id: string

  @column()
  public user_id: string

  @column()
  public save_login_info: boolean

  @column.dateTime({ autoCreate: true })
  public createdAt: DateTime

  @column.dateTime({ autoCreate: true, autoUpdate: true })
  public updatedAt: DateTime
}
