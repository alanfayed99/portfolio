import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class RoleRestriction {
  public async handle({ auth, response }: HttpContextContract, next: () => Promise<void>, roles: string[]) {
    const user = auth.user

    if (user && roles.includes(user.role)) {
      return await next()
    }

    return response.forbidden({ error: 'Forbidden access' })
  }
}
