import BaseSeeder from '@ioc:Adonis/Lucid/Seeder'
import HelpTopic from 'App/Models/HelpTopic'

export default class HelpTopicSeederSeeder extends BaseSeeder {
  public async run() {
    await HelpTopic.createMany([
      {
        col_order: 2,
        title: {
          id: 'Pertanyaan sering ditanyakan',
          en: 'Frequently asked topics',
        },
      },
      {
        col_order: 1,
        title: {
          id: 'Kesalahan & Gangguan Aplikasi',
          en: 'App Issue',
        },
      },
      {
        title: {
          id: 'Kesalahan & Gangguan Aplikasi',
          en: 'App Issue',
        },
      },
      {
        col_order: 3,
        title: {
          id: 'Tentang Sobatlana',
          en: 'About Sobatlana',
        },
      },
    ])
    // Write your database queries inside the run method
  }
}
