import { faker } from '@faker-js/faker'
import BaseSeeder from '@ioc:Adonis/Lucid/Seeder'
import Location from 'App/Models/Location'
import User from 'App/Models/User'
import { nanoid } from 'nanoid'
import { DateTime } from 'luxon'
import Post from 'App/Models/Post'
import { PostType, PostVisibility } from 'App/Types/Post'

export default class FakeDatasets extends BaseSeeder {
  public async run() {
    const users = await this.seedUsers(200)
    const locations = await this.seedLocations(300)
    await this.seedPosts(1000, users, locations)
  }

  private async seedUsers(totalUser: number) {
    const userSeeders = Array.from(Array(totalUser).keys()).map(() => {
      const name = faker.name.findName()
      const [firstName, lastName] = name.split(' ')
      const username = faker.internet.userName(firstName, lastName)
      const email = faker.internet.email(firstName).toLowerCase()
      return {
        email,
        username,
        fullname: name,
        password: 'test1234',
        gender: faker.name.gender(true).toLowerCase() as 'male' | 'female',
        birthdate: DateTime.fromJSDate(faker.date.birthdate()),
      }
    })

    return User.createMany(userSeeders)
  }

  private async seedLocations(totalLocation: number) {
    const definedPosition: [lat: number, long: number][] = [
      [-8.098564, 112.165599],
      [-7.967057, 112.63416],
      [-7.299793, 112.745641],
      [-7.809013, 110.436611],
      [-6.994507, 110.423512],
      [-6.200048, 106.824366],
      [-6.17718, 106.641718],
      [-6.262505, 106.705576],
      [-7.560822, 110.788777],
      [-8.660099, 115.205371],
    ]

    const locationSeeders = Array.from(Array(totalLocation).keys()).map(() => {
      const startCoordinate = faker.helpers.arrayElement(definedPosition)
      const [lat, long] = faker.address.nearbyGPSCoordinate(startCoordinate, 20, true)

      return {
        name: faker.address.streetName(),
        place_id: nanoid(),
        formatted_address: faker.address.streetAddress(true),
        lat: Number(lat),
        long: Number(long),
      }
    })

    return Location.createMany(locationSeeders)
  }

  private async seedPosts(totalPost: number, users: User[], locations: Location[]) {
    const posts = Array.from(Array(totalPost).keys()).map(() => {
      return {
        user_id: faker.helpers.arrayElement(users).id,
        content: faker.lorem.sentence(),
        visibility: faker.helpers.arrayElement(['public', 'close_friend']) as PostVisibility,
        location_id: faker.helpers.arrayElement(locations).id,
        type: 'yuks' as PostType,
      }
    })

    return Post.createMany(posts)
  }
}
