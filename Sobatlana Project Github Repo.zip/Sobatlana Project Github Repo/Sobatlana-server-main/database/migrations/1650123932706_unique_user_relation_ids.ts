import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class UserRelations extends BaseSchema {
  protected tableName = 'user_relations'

  public async up() {
    this.schema.alterTable(this.tableName, (table) => {
      table.unique(['following_id', 'follower_id'])
    })
  }
}
