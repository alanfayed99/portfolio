import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class SubHelpTopics extends BaseSchema {
  protected tableName = 'sub_help_topics'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').primary()
      table.integer('help_topic_id').unsigned()
      table.integer('col_order').nullable()
      table.json('title').notNullable()
      table.json('content').notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relationship
      table.foreign('help_topic_id').references('help_topics.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
