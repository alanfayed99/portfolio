import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class Posts extends BaseSchema {
  protected tableName = 'posts'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('user_id').notNullable()
      table.text('content').nullable()
      table.enum('visibility', ['public', 'close_friend']).defaultTo('public').notNullable()
      table.uuid('location_id').nullable()
      table.enum('type', ['yuks', 'post']).notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relationship
      table.foreign('user_id').references('users.id').onUpdate('cascade').onDelete('cascade')
      table.foreign('location_id').references('locations.id').onUpdate('cascade').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
