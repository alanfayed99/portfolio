import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class HelpTopics extends BaseSchema {
  protected tableName = 'help_topics'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').primary()
      table.json('title').notNullable()
      table.integer('col_order').nullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
