import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class CreateUserCloseFriends extends BaseSchema {
  protected tableName = 'close_friends'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('user_id').notNullable()
      table.uuid('friends_id').notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      //relationship
      table.foreign('user_id').references('users.id').onDelete('cascade')
      table.foreign('friends_id').references('users.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
