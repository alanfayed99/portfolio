import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class MyInterests extends BaseSchema {
  protected tableName = 'my_interests'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('user_id').notNullable()
      table.uuid('interest_list_id').notNullable()

      table.foreign('user_id').references('users.id').onUpdate('cascade').onDelete('cascade')
      table.foreign('interest_list_id').references('interest_lists.id').onUpdate('cascade').onDelete('cascade')
      table.unique(['user_id', 'interest_list_id'])
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
