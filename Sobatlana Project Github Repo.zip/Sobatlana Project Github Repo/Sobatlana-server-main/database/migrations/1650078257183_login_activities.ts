import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class LoginActivities extends BaseSchema {
  protected tableName = 'login_activities'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('security_config_id').notNullable()
      table.string('device_name').nullable()
      table.string('city').nullable()
      table.string('country').nullable()
      table.float('lat').nullable()
      table.float('long').nullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relationship
      table.foreign('security_config_id').references('security_configurations.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
