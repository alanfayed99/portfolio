import BaseSchema from '@ioc:Adonis/Lucid/Schema'
export default class UsersSchema extends BaseSchema {
  protected tableName = 'users'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.string('email', 255).notNullable()
      table.string('password', 180).notNullable()
      table.enum('role', ['admin', 'user']).defaultTo('user').notNullable()
      table.string('remember_me_token').nullable()
      table.string('username', 30).notNullable()
      table.string('fullname').nullable()
      table.dateTime('birthdate').nullable()
      table.enum('gender', ['male', 'female']).nullable()
      table.text('bio').nullable()
      table.string('photo').nullable()
      table.string('background_cover').nullable()
      table.text('google_auth_id').nullable()
      table.text('apple_auth_id').nullable()

      table.timestamp('created_at', { useTz: true }).notNullable()
      table.timestamp('updated_at', { useTz: true }).notNullable()
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
