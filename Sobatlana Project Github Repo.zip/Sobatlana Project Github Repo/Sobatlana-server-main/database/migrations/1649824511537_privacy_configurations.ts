import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class PrivacyConfigurations extends BaseSchema {
  protected tableName = 'privacy_configurations'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('user_id').notNullable().unique()
      table.boolean('is_private').notNullable().defaultTo(false)
      table
        .json('comment')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            limit_comments: false,
            limit_values: 20,
          })
        )
      table
        .json('post')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            hide_comments: false,
            hide_likes: false,
            hide_views: false,
          })
        )
      table
        .json('mentions')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            allow_mentions_from: 'all',
          })
        )

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relation
      table.foreign('user_id').references('users.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
