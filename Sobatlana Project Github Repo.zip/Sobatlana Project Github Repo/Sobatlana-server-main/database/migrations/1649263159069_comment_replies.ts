import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class CommentReplies extends BaseSchema {
  protected tableName = 'comment_replies'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('comment_id').notNullable()
      table.uuid('user_id').notNullable()
      table.text('comment').notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      table.foreign('comment_id').references('comments.id').onDelete('cascade')
      table.foreign('user_id').references('users.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
