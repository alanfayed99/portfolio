import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class Notifications extends BaseSchema {
  protected tableName = 'notifications'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('user_id').notNullable()
      table.uuid('user_related')
      table.text('content').notNullable()
      table.enum('type', ['follow', 'like', 'mentioned', 'personal']).notNullable()
      table.uuid('post_related_id')

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      //references
      table.foreign('user_id').references('users.id').onDelete('cascade')
      table.foreign('user_related').references('users.id').onDelete('cascade')
      table.foreign('post_related_id').references('posts.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
