import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class LocationCategories extends BaseSchema {
  protected tableName = 'location_categories'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('location_id').notNullable()
      table.uuid('location_type_id').notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relationship
      table.foreign('location_id').references('locations.id').onUpdate('cascade').onDelete('cascade')
      table.foreign('location_type_id').references('location_types.id').onUpdate('cascade').onDelete('cascade')

      //unique
      table.unique(['location_id', 'location_type_id'])
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
