import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class CommentLikes extends BaseSchema {
  protected tableName = 'comment_likes'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.increments('id').primary()
      table.uuid('user_id').notNullable()
      table.uuid('comment_id').notNullable()

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relationship
      table.foreign('user_id').references('users.id').onUpdate('cascade').onDelete('cascade')
      table.foreign('comment_id').references('comments.id').onUpdate('cascade').onDelete('cascade')
      table.unique(['user_id', 'comment_id'])
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
