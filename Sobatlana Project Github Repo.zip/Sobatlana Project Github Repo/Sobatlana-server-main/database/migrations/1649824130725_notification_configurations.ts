import BaseSchema from '@ioc:Adonis/Lucid/Schema'

export default class NotificationConfigurations extends BaseSchema {
  protected tableName = 'notification_configurations'

  public async up() {
    this.schema.createTable(this.tableName, (table) => {
      table.uuid('id').primary().defaultTo(this.raw('uuid_generate_v4 ()'))
      table.uuid('user_id').notNullable().unique()
      table
        .json('message')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            new_message: true,
            message_request: true,
          })
        )
      table
        .json('people')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            new_follower: true,
            recommendation: false,
            follow_request: true,
          })
        )
      table
        .json('interaction')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            post_liked: true,
            new_comment: true,
            comment_liked: false,
            name_mentioned: true,
            account_tagged: true,
          })
        )
      table
        .json('security')
        .notNullable()
        .defaultTo(
          JSON.stringify({
            password_changed: true,
            new_login: true,
          })
        )

      /**
       * Uses timestamptz for PostgreSQL and DATETIME2 for MSSQL
       */
      table.timestamp('created_at', { useTz: true })
      table.timestamp('updated_at', { useTz: true })

      // relation
      table.foreign('user_id').references('users.id').onDelete('cascade')
    })
  }

  public async down() {
    this.schema.dropTable(this.tableName)
  }
}
