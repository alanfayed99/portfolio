declare module '@ioc:Adonis/Addons/Sentry' {
  import * as Sentry from '@sentry/node'
  import * as Tracing from '@sentry/tracing'
  export { Sentry, Tracing }
}
