/*
|--------------------------------------------------------------------------
| Routes
|--------------------------------------------------------------------------
|
| This file is dedicated for defining HTTP routes. A single file is enough
| for majority of projects, however you can define routes in different
| files and just make sure to import them inside this file. For example
|
| Define routes in following two files
| ├── start/routes/cart.ts
| ├── start/routes/customer.ts
|
| and then import them inside `start/routes.ts` as follows
|
| import './routes/cart'
| import './routes/customer''
|
*/

import Route from '@ioc:Adonis/Core/Route'

Route.get('/', () => ({ 'app-name': 'sobatlana' }))

Route.group(() => {
  //authentication
  Route.post('/auth/register', 'AuthController.register')
  Route.post('/auth/login', 'AuthController.login')
  Route.post('/auth/login/refresh-token', 'AuthController.refreshTokenLogin')

  // protected routes
  Route.group(() => {
    // auth
    Route.post('/auth/logout', 'AuthController.logout')

    // current user
    Route.get('/me', 'UsersController.getMyProfile')
    Route.patch('/me', 'UsersController.updateUser')
    Route.patch('/me/password', 'UsersController.updatePassword')
    Route.post('/me/my-interest', 'UsersController.addMyInterest')
    Route.get('/me/stats', 'UsersController.getMyStats')
    Route.get('/me/posts', 'UsersController.getMyPosts')
    Route.post('/me/device-token', 'DeviceTokensController.storeMyDeviceToken')
    Route.delete('/me/device-token/:token', 'DeviceTokensController.revokeMyDeviceToken')

    //interest-list
    Route.get('/interest-lists', 'InterestListsController.index')
    Route.post('/interest-lists', 'InterestListsController.store')

    // location
    Route.get('/location/search', 'LocationsController.searchLocation')

    // posts
    Route.get('/posts', 'PostsController.index')
    Route.post('/posts', 'PostsController.store')
    Route.delete('/posts/:id', 'PostsController.destroy')
    Route.post('/posts/:id/like', 'PostsController.likePost')
    Route.delete('/posts/:id/like', 'PostsController.unlikePost')
    Route.get('/posts/:id/comment', 'PostsController.getPostComments')
    Route.post('/posts/:id/comment', 'PostsController.commentAPost')
    Route.get('/posts/:id/comment/:commentId/reply', 'PostsController.getCommentReplies')
    Route.post('/posts/:id/comment/:commentId/reply', 'PostsController.replyAComment')
    Route.post('/posts/:id/bookmark', 'PostsController.bookmarkPost')
    Route.delete('/posts/:id/bookmark', 'PostsController.unBookmarkPost')

    // comments
    Route.post('/comments/:id/like', 'CommentsController.likeComment')
    Route.delete('/comments/:id/like', 'CommentsController.unLikeComment')

    // configuration
    Route.get('/configuration/notification', 'ConfigurationsController.getNotifConfig')
    Route.patch('/configuration/notification', 'ConfigurationsController.updateNotifConfig')
    Route.get('/configuration/privacy', 'ConfigurationsController.getPrivacyConfig')
    Route.patch('/configuration/privacy', 'ConfigurationsController.updatePrivacyConfig')
    Route.get('/configuration/security', 'ConfigurationsController.getSecurityConfig')
    Route.patch('/configuration/security', 'ConfigurationsController.updateSecurityConfig')

    // user
    Route.get('/user/:userId/stats', 'UsersController.getUserStats')
    Route.get('/user/:userId/posts', 'PostsController.getUserPosts')
    Route.post('/user/:userId/follow', 'UsersController.followUser')
    Route.post('/user/:userId/unfollow', 'UsersController.unfollowUser')
    Route.delete('/user/:userId/followers', 'UsersController.removeMyFollower')
  }).middleware('auth:jwt')

  // help-topic
  Route.get('/help-topics', 'HelpTopicsController.index')
  Route.get('/help-topics/:helpId', 'HelpTopicsController.getSubHelpTopics')

  //protected
}).prefix('api')

Route.get('/video', ({ view }) => view.render('video'))
